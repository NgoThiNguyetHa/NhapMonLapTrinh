#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
int chon;
int i, j, n,m;
void checkSNguyenTo(n) {
	int dem=0;
   for(i=2;i<n; i++){
		if(n%i==0){
			dem++;
		}
	}
	if(dem==0){
		printf(" %d la so nguyen to \n", n);
	}
	else{
		printf("%d khong phai la so nguyen to \n", n);
	}
}
void checkSChinhPhuong(n){
    int check=0;
	for(i=1 ; i<=n ; i++ ){
		if(i*i==n){
			check=1;//la so chinh phuong
		    break;
		}
	}
	if(check==1){
		printf(" %d la so chinh phuong ", n);
	}
	else{
		printf(" %d khong phai so chinh phuong",n);	
	}
}
void uocChungBoiChung(n,m){
nhaplai1:	printf("Nhap 2 so n, m > 0: ");
	scanf("%d%d", &n, &m);
    if(n==0 && m==0){
		printf("Khong co UCLN va BCNN");
	}
	else if(n>0 && m>0){
		int a=n*m;
		while(n!=m){
			
			if(n>m){
				n-=m;
			}
			else{
				m-=n;
			}
		}
		printf("UCLN = %d\n",n);
		printf("BCNN = %d",a/n);
	}
	
	else if(n==0 || m==0){
		if(n==0){
			printf("UCLN = %d va khong co BCNN", m);
		}
		if(m==0){
			printf("UCLN = %d va khong co BCNN", n);
		}
	}
	
	else{
		printf("Nhap lai n, m > 0 \n");
		goto nhaplai1;
	}
}
void tienHat(n,m){
	int soTien;
	printf("Nhap gio bat dau: ");
	scanf("%d",&n);
	printf("Nhap gio ket thuc: ");
	scanf("%d",&m);
	if(n>=12 && m<=23 && n<m){
		if(n>=14 && n<=17){
			if( (m-n) <= 3){
				soTien = (m-n)*150000*0.9;
				printf("So tien can thanh toan la: %d", soTien);
			}
			else if( (m-n) > 3){
				soTien = ((m-n-3)*150000*0.7+450000)*0.9;
				printf("So tien can thanh toan la: %d", soTien);
			}
		}
		else if(n>=12 && n<14){
			if( (m-n) <= 3){
				soTien = (m-n)*150000;
				printf("So tien can thanh toan la: %d", soTien);
			}
			else if( (m-n) > 3){
				soTien = (m-n-3)*150000*0.7+450000;
				printf("So tien can thanh toan la: %d", soTien);
			}
		}
		else if(n>17 && n<=23){
			if( (m-n) <= 3){
				soTien = (m-n)*150000;
				printf("So tien can thanh toan la: %d", soTien);
			}
			else if( (m-n) > 3){
				soTien = (m-n-3)*150000*0.7+450000;
				printf("So tien can thanh toan la: %d", soTien);
			}
		}
	}
	else{
		printf("Quan khong hoat dong vao gio nay");
	}
}
void tienDien(){
	double soDien,soTien, b1=50*1678, b2=50*1734, b3=100*2014, b4=100*2536, b5=100*2834;
     printf("Ban da den voi chuc nang so 4\n");
		nhaplai2:	printf("Nhap so dien tieu thu la: ");
	scanf("%lf",&soDien);
		if(soDien<0){
		printf("Moi nhap lai so dien >0 \n");
		goto nhaplai2;
		}
	else if(soDien>=0 && soDien<=50){
		soTien=soDien*1678;
		printf("So tien can phai dong la: %.2lf", soTien*1.1 );
	}
	else if(soDien<=100){
		soTien=b1+(soDien-50)*1734;
		printf("So tien can phai dong la: %.2lf", soTien*1.1);
	}
	else if(soDien<=200){
		soTien=b1+b2+(soDien-100)*2014;
		printf("So tien can phai dong la: %.2lf", soTien*1.1);
	}
	else if(soDien<=300){
		soTien=b1+b2+b3+(soDien-200)*2536;
		printf("So tien can phai dong la: %.2lf", soTien*1.1);
	}
	else if(soDien<=400){
		soTien=b1+b2+b3+b4+(soDien-300)*2834;
		printf("So tien can phai dong la: %.2lf", soTien*1.1);
	}
	else if(soDien>400){
		soTien=b1+b2+b3+b4+b5+(soDien-400)*2927;
		printf("So tien can phai dong la: %.2lf", soTien*1.1);
	}
}
void doiTien(){
	int soTien;
	int menhGia[9]={500, 200, 100, 50, 20, 10, 5, 2, 1};
	printf("Nhap so tien ban can doi: ");
	scanf("%d", &soTien);
	for(i=0; i<9; i++){
		if(i==0){
			while(soTien <= menhGia[i]){
				i++;
			}
		}
		if(soTien >= menhGia[i]){
		j = soTien/menhGia[i];
		printf("Co %d to %d \n", j, menhGia[i]);
		soTien = soTien-(j*menhGia[i]);
		if(soTien==0){
			break;
		}
		}
	}
}
void vayTien(){
	int tienVay,laiPhaiTra, gocPhaiTra, tienTra, tongTien=0;
	printf("So tien ban muon vay la: ");
	scanf("%d", &tienVay);
	gocPhaiTra = tienVay/12; //tien goc phai tra hang thang
	for(i=1; i<=12; i++){
	    laiPhaiTra = tienVay*0.05; //lai phai tra hang thang
	    tienTra = laiPhaiTra+gocPhaiTra;//tong tien tra hang thang
	    tongTien+=tienTra;
	    tienVay-=gocPhaiTra;
	    printf("Tong tien phai tra thang thu %d la: %d \n",i,tienTra);
	}
    printf("Tong tien ban phai tra sau 12 thang la: %d",tongTien);
}
void sv(){
	
	struct sinhvien{
	char tenSV[50];
	float diemTB;
    }mangSV[100],svTemp ;
    printf("Nhap so sinh vien muon them: ");
	scanf("%d",&n);
	for (i=0; i<n; ++i){
		printf("Nhap sinh vien thu %d: \n",i+1);
		printf("Nhap ten sinh vien:");
		fgetc(stdin);
		gets(mangSV[i].tenSV);
	    printf("Nhap diem cua sinh vien:");
		scanf("%f",&mangSV[i].diemTB);
    }
    for(i=0; i<n-1; i++){
		for(j=i+1; j<n; j++){
			if(mangSV[i].diemTB < mangSV[j].diemTB){
			svTemp = mangSV[i] ;
			mangSV[i] = mangSV[j];
			mangSV[j] = svTemp;	
			}
		}
	    }
	printf("Sap xep theo diem giam dan la: \n");    
	for (i=0; i<n; i++){
		
	    printf("Sinh vien thu %d \n",i+1);
	    printf("Ten sv: %s |",mangSV[i].tenSV);
		printf("Diem: %.2f |",mangSV[i].diemTB);	
	if(mangSV[i].diemTB>=9){
		printf("Hoc luc: Xuat sac \n");
	}
	else if(mangSV[i].diemTB>=8){
		printf("Hoc luc: Gioi \n");
	}
	else if(mangSV[i].diemTB>=6.5){
		printf("Hoc luc: Kha \n");
	}
	else if(mangSV[i].diemTB>=5){
		printf("Hoc luc: Trung binh \n");
	}
	else if(mangSV[i].diemTB<5){
	    printf("Hoc luc: Yeu \n");
	}
	}
			
}
void game(n,m){
	int soNgauNhien[2];
	int dem=0;
	srand((int) time(0));
	printf("Moi chon 2 so tu 1-15:");
	scanf("%d%d", &n, &m);
	for(i=0; i<2; i++){
		int so= rand()%15+1;
		soNgauNhien[i]=so;
	}
	for(i=0; i<2; i++){
		if(n == soNgauNhien[i]){
			dem++;
		}
		if(m == soNgauNhien[i]){
			dem++;
		}
	}
	printf("So ban da chon la: %d, %d \n", n, m);
	printf("So ngau nhien la: %d, %d \n",soNgauNhien[0], soNgauNhien[1]);
	if (dem==1){
		printf("Chuc mung ban da trung giai nhi");
	}
	else if(dem==2){
		printf("Chuc mung ban da trung giai nhat");
	}
	else{
		printf("Chuc ban may man lan sau");
	}
}
void tinhPhanSo(){
	struct phanSo{
		int tuSo;
		int mauSo;
	}so1, so2, tong, hieu, tich, thuong;
	printf("Nhap phan so thu nhat :");
	scanf("%d%d",&so1.tuSo, &so1.mauSo);
	printf("Nhap phan so thu hai :");
	scanf("%d%d",&so2.tuSo, &so2.mauSo);
	tong.tuSo = so1.tuSo*so2.mauSo + so2.tuSo*so1.mauSo;
	tong.mauSo = so1.mauSo*so2.mauSo;
	hieu.tuSo = so1.tuSo*so2.mauSo - so2.tuSo*so1.mauSo;
	hieu.mauSo = so1.mauSo*so2.mauSo;
	tich.tuSo = so1.tuSo*so2.tuSo;
	tich.mauSo = so1.mauSo*so2.mauSo;
	thuong.tuSo = so1.tuSo*so2.mauSo;
	thuong.mauSo = so2.tuSo*so1.mauSo;
	printf("Tong 2 phan so la: %d/%d \n", tong.tuSo, tong.mauSo);
	printf("Hieu 2 phan so la: %d/%d \n", hieu.tuSo, hieu.mauSo);
	printf("Tich 2 phan so la: %d/%d \n", tich.tuSo, tich.mauSo);
	printf("Thuong 2 phan so la: %d/%d \n", thuong.tuSo, thuong.mauSo);
}
int main(){
	do{
	
printf("\n          Menu         \n");
printf("1. Kiem tra so nguyen \n");
printf("2. Tim uoc so chung va boi so chung \n");
printf("3. Tinh tien cho quan karaoke \n");
printf("4. Tinh tien dien \n");
printf("5. Chuc nang doi tien \n");
printf("6. Tinh lai suat vay ngan hang vay tra gop \n");
printf("7. Sap xep thong tin sinh vien \n");
printf("8. Game FPOLY-LOTT \n");
printf("9. Tinh toan phan so \n");
printf("10. Chuong trinh thoat \n");
printf("\n\n Moi chon chuong trinh :");
scanf("%d", &chon);
switch(chon){
	case 1: {
	printf("Da chon chuong trinh 1 \n");
	printf("\n Nhap so n: ");
	scanf("%d",&n);
	checkSNguyenTo(n);
	checkSChinhPhuong(n);
	break;
	}
    case 2:{ 
	printf("Da chon chuong trinh 2 \n");
	uocChungBoiChung(n,m);
	break;
	}
	case 3: {
	printf("Da chon chuong trinh 3 \n");
	tienHat(n,m);
	break;
	}
	case 4: {
	printf("Da chon chuong trinh 4 \n");
	tienDien();
	break;
	}
	case 5: {
	printf("Da chon chuong trinh 5 \n");
	doiTien();
	break;
	}
	case 6: {
	printf("Da chon chuong trinh 6 \n");
	vayTien();
	break;
	}
	case 7:{ 
	printf("Da chon chuong trinh 7 \n");
	sv();
	break;
	}
	case 8: {
	printf("Da chon chuong trinh 8 \n");
    game(n,m);
	break;
	}
	case 9: {
	printf("Da chon chuong trinh 9 \n");
	tinhPhanSo();
	break;
	}
	case 10:{
	printf("-----Ket thuc chuong trinh-----");
	break;
	}
	default: printf("Hay nhap gia tri tu 1-10");
}
}while(chon!=10);	
return 0;
}
