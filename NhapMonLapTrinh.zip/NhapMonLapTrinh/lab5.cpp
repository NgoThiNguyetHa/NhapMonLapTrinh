#include<stdio.h>
#include<math.h>
int timMax( int a,int b,int c){
    if(a>b && a>c){return a;}
	if(b>a && b>c){return b;}
	if(c>a && c>b){return c;}
	}
int checkYear(int year){
	int flag=0;
	if( year % 400 == 0){flag=1;
	return flag;}
	if( year % 4 == 0 && year % 100 != 0){flag=1;}
	return flag;
}
void hoanDoi( int *x, int *y){
	int temp;
	temp=*x;
	*x=*y;
	*y=temp;
}
int main(){
	int choice;
	printf("1. Hien thi so lon nhat trong 3 so \n");
	printf("2. Kiem tra nam nhuan \n");
	printf("3. Hoan vi 2 gia tri \n");
	printf("Hay chon chuong trinh: ");
	scanf("%d", &choice);
	switch(choice){
		case 1:
		    printf("Da chon chuong trinh 1 \n");
		    int max;
			max=timMax(3,5,10);
			printf("So lon nhat trong 3 so la: %d", max );
			break;
		case 2:
			printf("Da chon chuong trinh 2 \n");
			if (checkYear(2001)==1){
		    printf("Day la nam nhuan");	}
			else printf("Day khong phai nam nhuan");
			break;
		case 3:
			printf("Da chon chuong trinh 3 \n");
			int x=2, y=3;
			hoanDoi(&x,&y);
			printf("Hoan vi cua 2 gia tri x, y la: %d %d",x,y );
			break;
	    Default: 
		printf("Hay chon gia tri trong khoang 1-3 \n");
		break;	
	}
}

