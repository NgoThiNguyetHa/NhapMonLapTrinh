#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main(){
	int choice;
	int min, max;
	int x, i;
	int a, b;
	int e, f;
	int dem=0, count=0;
	do{
	printf("\n 1.Tinh trung binh tong cac so chia het cho 2 \n 2.Xac dinh so nguyen to\n 3.Xac dinh so chinh phuong ");
    printf("\n Hay chon chuc nang ");
	scanf("%d", &choice);	
	switch(choice){
		case 1: {
	    printf("\n Da chon chuong trinh 1");
		printf("\n Nhap gia tri min, max : ", min, max);
	scanf("%d %d", &min, &max);
	int x=min;
	float tong=0, biendem=0; 
	if(x=max){
	 if(x%2!=0){
	 	printf("Trung binh cua tong la: 0 ");
	 return 0;
	}
	}
	for(x=min;x<=max;x++){
		if(x%2==0){
			tong+=x;
			biendem++;
		}
	}
	for(x=min; x>=max; x--){
		if(x%2==0){
		tong+=x;
		biendem++;
		}
	}
	printf("Trung binh tong cac so tu nhien tu min den max chia het cho 2 la: %.1f", tong / biendem);
	break;}
	case 2:{
	
	
		
	 printf("\n Da chon chuong trinh 2");
	nhaplai2:	printf("\n Nhap so a: ", a);
	scanf("%d",&a);
	if(a<2){
		printf("Moi nhap lai a>0: ", a);
		goto nhaplai2;
	}
	for(b=2;b<a; b++){
		if(a%b==0){
			dem++;
			
		}
		
	}
	if(dem==0){
		printf(" %d la so nguyen to \n", a);
	}
	else{
		printf("%d khong phai la so nguyen to \n", a);
	}
	break;}
	case 3:{
	printf("\n Da chon chuong trinh 3 ");
	printf("\n Nhap gia tri e la: ");
	scanf("%d", &e);
	if(e<0){
	printf(" %d khong phai so chinh phuong ",x);
	return 0;
	}
	for(f=1 ; f<=e ; f++ ){
		if(f*f==e){
			printf(" %d la so chinh phuong ", e);
			return 0;
			}
		}
		printf(" %d khong phai so chinh phuong",e);
		break;
	}
		default: printf("\n Hay chon gia tri  trong khoang 1-3");
		break;		
	}
    }
    while(choice!=3);
	return 0;
}
