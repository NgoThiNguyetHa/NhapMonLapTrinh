#include<stdio.h>
#include<string.h>
struct sinhvien{
	char maSV[50];
	char tenSV[50];
	char nganhHoc[50];
	float diemTB;
    }mangSV[50],svTemp ;
int i,j,n;
int main(){
	int chon;
	printf("Nhap so sinh vien muon them: ");
	scanf("%d",&n);
	for (i=0; i<n; ++i){
		printf("Nhap sinh vien thu %d: \n",i+1);
		printf("Nhap ma sinh vien:");
		fgetc(stdin);
		gets(mangSV[i].maSV);
		printf("Nhap ten sinh vien:");
		gets(mangSV[i].tenSV);
	    printf("Nhap nganh hoc cua sinh vien:");
		gets(mangSV[i].nganhHoc);
		printf("Nhap diem cua sinh vien:");
		scanf("%f",&mangSV[i].diemTB);
    }
    do{
	printf("\n         MENU LAB 8          \n ");
	printf("1. Luu thong tin sinh vien \n ");
	printf("2. Sap xep sinh vien theo diem tang dan \n");
	printf("3. Tim kiem sinh vien \n");
	printf("4. Chuong trinh thoat \n");
	printf("Nhap chuong trinh can chon: ");
	scanf("%d", &chon);
	switch(chon){
		case 1:{
		for (i=0;i<n;i++){
		printf("Thong tin sv %d la: \n",i+1 );
		printf("Ma sv: %s| Ten sv: %s| Nganh hoc: %s| Diem: %.2f \n",mangSV[i].maSV, mangSV[i].tenSV, mangSV[i].nganhHoc, mangSV[i].diemTB);
	    }
			break;
			}
		case 2:{
			for(i=0; i<n-1; i++){
		for(j=i+1; j<n; j++){
			if(mangSV[i].diemTB > mangSV[j].diemTB){
			svTemp = mangSV[i] ;
			mangSV[i] = mangSV[j];
			mangSV[j] = svTemp;	
			}
		}
	    }
			printf("Sap xep theo diem tang dan la: \n");
			for(i=0;i<n;i++){
	    printf("sinh vien thu %d \n",i+1);
	    printf("Ma sv: %s| Ten sv: %s| Nganh hoc: %s| Diem: %.2f \n",mangSV[i].maSV, mangSV[i].tenSV, mangSV[i].nganhHoc, mangSV[i].diemTB);
		}	
			break;
			}
		case 3:{
				char mssv[50];
	printf("Nhap ma so sinh vien can tim:");
	fgetc(stdin);
   		gets(mssv);
	for (i=0; i<n; i++){
		if(strcmp(mssv,mangSV[i].maSV)==0){
			printf("Ma sv: %s| Ten sv: %s| Nganh hoc: %s| Diem: %.2f \n",mangSV[i].maSV, mangSV[i].tenSV, mangSV[i].nganhHoc, mangSV[i].diemTB);
			break;
		}
	}
	if(strcmp(mssv,mangSV[i].maSV)!=0){
			printf("Khong co sinh vien nay\n");
		}		
			break;
			}
		case 4:{
			printf("Ket thuc chuong trinh");
			break;
			}
			default : printf("Nhap dung gia tri");	
	}
	} while (chon!=4);
	return 0;
	}
