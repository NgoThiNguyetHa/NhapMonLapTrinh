#include<stdio.h>
#include<string.h>
char xau1[100], xau2[100], xau3[100], xau4[100], xau5[100] ;
void bai1(){
	int i=0, dem1=0, dem2=0;
	while(xau1[i++] != '\0'){
		if(xau1[i]=='a'|| xau1[i]=='i' || xau1[i]=='e' || xau1[i]=='u' || xau1[i]=='o'){
			dem1++;
		}
	    else if(xau1[i]>'a' && xau1[i]<='z'){
	    	dem2++;
		}
	printf("Co %d nguyen am va co %d phu am",dem1,dem2); 
}
}
int main(){
	int chon;
	do{
	printf("         MENU LAB 7          \n ");
	printf("1. Dem so nguyen am va phu am \n ");
	printf("2. Dang nhap bang username va password \n");
	printf("3. Sap xep chuoi theo chu cai \n");
	printf("4. Chuong trinh thoat \n");
nhaplai:	printf("Nhap chuong trinh can chon: ");
	scanf("%d", &chon);
	switch(chon){
		case 1:
			printf("Nhap xau 1 : ");
	        gets(xau1);
	        puts(xau1);
	        strlwr(xau1);
			bai1();
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			printf("Ket thuc chuong trinh");
			break;
			default : printf("Nhap dung gia tri");	
			goto nhaplai;		
	}
	} while (chon!=4);
	return 0;
	}
