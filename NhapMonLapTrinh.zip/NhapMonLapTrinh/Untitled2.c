#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void bai1(){
	char tenmt[50];
	char hangmt[50];
	float giatien;
	printf("nhap thong tin may tinh \n");
	printf("ten may tinh la \n");
	fgetc(stdin);
	gets(tenmt);
	printf("hang may tinh la \n");
	gets(hangmt);
	printf("gia tien may tinh la \n");
	scanf("%f",&giatien);
	puts(tenmt);
	puts(hangmt);
	printf("gia tien la %.2f \n",giatien);
}

void bai2(){
	int a;
	printf("nhap vao diem \n");
	scanf("%d",&a);
	if(a>=0&&a<5){
		printf("diem truot la %d \n",a);
	}
	else{
		printf("diem do la %d \n",a);
	}
}
void bai3(){
	int sl;
	printf("nhap so luong lop la \n");
	scanf("%d",&sl);
	int mang[sl];
	int dem=0;
	int i;
	for(i=0;i<sl;i++){
		printf("nhap mang si so lop [%d]= ",i+1);
		scanf("%d",&mang[i]);
	}
	printf("so luong lop la %d \n",sl);
	for(i=0;i<sl;i++){
		if(mang[i]>=40){
		dem++;
		}
	}
	printf("lop co si so >=40 la %d \n",dem);
	int max;
	max=mang[0];
	for(i=0;i<sl;i++){
		if(max<mang[i]){
			max=mang[i];
		}
	}
	printf("lop co si so lon nhat la %d \n",max);
}
int main(){
	int chon;
	do{
		printf("------menu-----\n");
		printf("1.nhap thong tin may tinh \n");
		printf("2.nhap thong tin diem \n");
		printf("3.nhap thong tin lop \n");
		printf("4.thoat \n");
		scanf("%d",&chon);
		switch(chon){
			case 1:{
				printf("da chon chuong trinh 1 \n");
				bai1();
				break;
			}
			case 2:{
				printf("da chon chuong trinh 2 \n");
				bai2();
				break;
			}
			case 3:{
				printf("da chon  chuong trinh 3 \n");
				bai3();
				break;
			}
		}
		  
	}while(chon!=4);
	return 0;
}
