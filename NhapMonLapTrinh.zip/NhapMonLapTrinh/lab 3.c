#include<stdio.h>
int main(){
	int chon;
	float diem, a, b, e, f, g;
	double soDien,soTien, b1=50*1678, b2=50*1734, b3=100*2014, b4=100*2536, b5=100*2834;
	printf("1.Tinh hoc luc cua sinh vien\n");
	printf("2.Giai phuong trinh bac 1\n");
	printf("3.Giai phuong trinh bac 2\n");
	printf("4.Tinh tien dien\n");
nhaplai1:	printf("Hay chon chuc nang: ");
	int cn;
	scanf("%d", &cn);
	switch(cn){
		case 1: printf("Ban da den voi chuc nang so 1\n");
		nhaplai3:	printf("Nhap diem cua sinh vien: ");
	scanf("%f",&diem);
	if(diem>10||diem<0){
	printf("Nhap lai diem cua sinh vien >=0 va <=10: ");
	goto nhaplai3;
	}
	if(diem>=9){
		printf("Sinh vien dat hoc luc xuat sac");
	}
	else if(diem>=8){
		printf("Sinh vien dat hoc luc gioi");
	}
	else if(diem>=6.5){
		printf("Sinh vien dat hoc luc kha");
	}
	else if(diem>=5){
		printf("Sinh vien dat hoc luc trung binh");
	}
	else if(diem>=3.5){
	printf("Sinh vien dat hoc luc yeu");
	}
	else if(diem<3.5){
		printf("Sinh vien dat hoc luc kem");
	}
		break;
		case 2: printf("Ban da den voi chuc nang so 2\n");
		printf("Nhap he so a: \n");
	scanf("%f", &a);
	printf("Nhap he so b: ");
	scanf("%f", &b);
	if(a==0 && b==0){
			printf("Phuong trinh co vo so nghiem\n");
		}
	else if(a==0 && b!=0){
		printf("Phuong trinh vo nghiem\n");
	}
	else{printf("Phuong trinh co nghiem la: %f", (-b)/a);
	}
		break;
		case 3: printf("Ban da den voi chuc nang so 3\n");
		printf("Nhap he so e: ");
	scanf("%f",&e);
	printf("Nhap he so f: ");
	scanf("%f", &f);
	printf("Nhap he so g: ");
	scanf("%f", &g);
	if(e==0){
		if(f==0 && g==0){printf("Phuong trinh vo so nghiem");}
		else if (f==0 && g!=0){	printf("Phuong trinh vo nghiem");}
		else{printf("Phuong trinh co nghiem la: %.2f",-g/f);}
    }
    else{float delta= f*f-4*e*g;
     if(delta<0){printf("Phuong trinh vo nghiem");}
     else if(delta==0){printf("Phuong trinh co nghiem kep la: %.2f",-f/2*e );}
     else{
     printf("Phuong trinh co nghiem 1 la: %.2f",(-f-sqrt(delta))/(2*e));
	 printf("Phuong trinh co nghiem 1 la: %.2f",(-f+sqrt(delta))/(2*e));
	 }
	 }
		break;
		case 4: printf("Ban da den voi chuc nang so 4\n");
		nhaplai2:	printf("Nhap so dien tieu thu la: ");
	scanf("%lf",&soDien);
		if(soDien<0){
		printf("Moi nhap lai so dien >0 \n");
		goto nhaplai2;
		}
	else if(soDien>=0 && soDien<=50){
		soTien=soDien*1678;
		printf("So tien can phai dong la: %.2lf", soTien*1.1 );
	}
	else if(soDien<=100){
		soTien=b1+(soDien-50)*1734;
		printf("So tien can phai dong la: %.2lf", soTien*1.1);
	}
	else if(soDien<=200){
		soTien=b1+b2+(soDien-100)*2014;
		printf("So tien can phai dong la: %.2lf", soTien*1.1);
	}
	else if(soDien<=300){
		soTien=b1+b2+b3+(soDien-200)*2536;
		printf("So tien can phai dong la: %.2lf", soTien*1.1);
	}
	else if(soDien<=400){
		soTien=b1+b2+b3+b4+(soDien-300)*2834;
		printf("So tien can phai dong la: %.2lf", soTien*1.1);
	}
	else if(soDien>400){
		soTien=b1+b2+b3+b4+b5+(soDien-400)*2927;
		printf("So tien can phai dong la: %.2lf", soTien*1.1);
	}

		break;
		default: printf("Ban chon khong dung bo chuc nang (1,2,3,4) \n");
		goto nhaplai1;
		break;
		}
		return 0;
		}
