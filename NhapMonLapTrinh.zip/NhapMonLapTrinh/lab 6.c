
#include<stdio.h>
#include<math.h>
int chon;
int n,m,i,j;
void bai1(){
	int trungBinh[n];
		for(i=0; i<n; i++){
			printf("Xin moi nhap vao vi tri thu trungBinh[%d]: ",i);
			scanf("%d", &trungBinh[i]);
		}
		float tong;
		float dem=0;
		for(i=0; i<n; i++){
			if(trungBinh[i]%3==0){
				tong+=trungBinh[i];
				dem++;
			}
		}
	printf("Trung binh tong cac so chia het cho 3 trong mang la: %.2lf ", tong/dem);	
}
void bai2(){
	int minMax[n];
		for(i=0; i<n; i++){
		printf("Xin moi nhap vao vi tri thu minMax[%d]: ",i);
		scanf("%d", &minMax[i]);
		}
		int max=minMax[0];
		for(i=0; i<n; i++){
			if (minMax[i]>max){
		    	max=minMax[i];
			}
		}
		printf("So lon nhat trong mang la: %d \n",max);
		int min=minMax[0];
		for(i=0; i<n; i++){
			if (minMax[i]<min){
		    	min=minMax[i];
		    }
		}
	    printf("So nho nhat trong mang la: %d", min);
}
void bai3(){
	int sapXep[n];
		for(i=0; i<n; i++){
		printf("Xin moi nhap vao vi tri thu sapXep[%d]: ",i);
		scanf("%d", &sapXep[i]);
		}
		int j, temp;
		for(i=0; i<n; i++){
			for(j=i+1; j<n; j++){
				if(sapXep[i] < sapXep[j]){
				temp=sapXep[i];
				sapXep[i] = sapXep[j];
				sapXep[j] = temp;
				}
			}
		}
		for(i=0; i<n; i++){
			printf("sapXep[%d] la: %d \n", i, sapXep[i]);
		}
}
void bai4(){
        int binhPhuong[n][m];
		for(i=0; i<n; i++){
			for(j=0; j<m; j++){
		        printf("Xin moi nhap vao mang vi tri thu binhPhuong[%d][%d] : ", i, j);
		        scanf("%d", &binhPhuong[i][j]);
		    }
		}
		for(i=0; i<n; i++){
			for(j=0; j<m; j++){
				int a=binhPhuong[i][j];
				a=a*a;
				printf("Binh phuong cua binhPhuong[%d][%d] la: %d \n",i,j, a);
		    }		
        }
}
int main(){
	do{
	
	printf(" \n              MENU                           \n");
	printf("1. Tinh trung binh tong cac so chia het cho 3 trong mang \n");
	printf("2. Tim gia tri nho nhat, lon nhat trong mang \n");
	printf("3. Sap xep mang theo thu tu giam dan \n");
	printf("4. Tinh binh phuong cac phan tu trong mang \n");
	printf("5. Chuong trinh thoat \n");
	printf("\n Hay chon chuc nang: ");
	scanf("%d", &chon);
	switch(chon){
		case 1: 
		printf("Da chon chuong trinh 1 \n");
		printf("Nhap so phan tu: ");
		scanf("%d",&n);
		bai1();
		break;
		
		case 2:
		printf("Da chon chuong trinh 2 \n");
		printf("Nhap so phan tu: ");
		scanf("%d",&n);
		bai2();
	    break;
		
	    case 3:
	    printf("Da chon chuong trinh 3 \n");
	    printf("Nhap so phan tu: ");
		scanf("%d",&n);
		bai3();
		break;
	    
		case 4: 
		printf("Da chon chuong trinh 4 \n");
	    printf("Nhap so hang, so cot : ", n,m);
		scanf("%d %d",&n, &m);
		bai4();
		break;
		
		case 5: 
		printf("______Ket thuc chuong trinh______");
		break;
    
        default: printf("Hay chon gia tri trong khoang 1-5");
		 break;
     }   
    } while (chon!=5);
    return 0;
}
