#include<stdio.h>
int main(){
	int chon;
	int a, b=0;
	double cd, cr;
	double r;
	double chuVi, dienTich;
	float diemToan, diemLy, diemHoa;
do{
	printf("Hay chon chuong trinh: ");
	scanf("%d", &chon);
	printf("\n 1.Tinh tong hieu ");
	printf("\n 2.Tinh chu vi, dien tich hcn");
	printf("\n 3.Tinh chu vi, dien tich hinh tron ");
	printf("\n 4.Tinh diem trung binh ");
	switch(chon){
		case 1: printf("\n Da chon chuong trinh 1");
		printf ("Nhap so a, b: ");
	scanf ("%d %d",&a, &b);
	int tong=a+b; 
	printf("Tong la: %d \n", tong);
	int hieu=a-b;
	printf("Hieu la: %d", hieu);
		break;
		case 2: printf("\n Da chon chuong trinh 2");
		printf("Nhap chieu dai: \n", cd);
	scanf("%lf", &cd);
	printf("Nhap chieu rong: ", cr);
	scanf("%lf", &cr);
	double chuVi= 2*(cd+cr);
	printf("Chu vi hinh chu nhat la: %lf\n", chuVi);
	double dienTich= cd*cr;
	printf("Dien tich hinh chu nhat la: %lf", dienTich);
		break;
		case 3: printf("\n Da chon chuong trinh 3");
		printf("Nhap ban kinh; ", r);
	scanf("%lf", &r);
	printf("Chu vi hinh tron la: %lf \n", chuVi= 2*3.14*r);
	printf("Dien tich hinh tron la: %lf ", dienTich= r*r*3.14);
		break;
		case 4: printf("\n Da chon chuong trinh 4");
		printf("Nhap diem Toan: ", diemToan);
	scanf("%f", &diemToan);
	printf("Nhap diem Ly: ", diemLy);
	scanf("%f", &diemLy);
	printf("Nhap diem Hoa: ", diemHoa);
	scanf("%f", &diemHoa);
	float diemTrungBinh=(diemToan*3+diemLy*2+diemHoa)/6;
	printf("Diem trung binh la: %f", diemTrungBinh);
		break;
		default: printf("\n Hay chon chuong trinh tu 1-4 ");
		break;
	}
	}
	while(chon!=4);
   return 0;
}
